import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home_page.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  String nama = '';
  String kelas = '';
  String email = '';
  String password = '';

  bool lihatPassword = false;

  bool isLoading = false;
  String? pesanError;

  Future<void> register() async {
    if (nama == '' || kelas == '' || email == '' || password == '') {
      setState(() {
        pesanError = 'Semua kolom harus diisi';
      });
      return;
    }

    if (password.length < 6) {
      setState(() {
        pesanError = 'Password minimal 6 karakter';
      });
      return;
    }

    setState(() {
      isLoading = true;
      pesanError = null;
    });

    try {
      UserCredential hasil = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(email: email, password: password);

      String uid = hasil.user!.uid;
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'user_id': uid,
        'name': nama,
        'email': email,
        'kelas': kelas,
        'created_at': DateTime.now(),
        'foto': '',
      });

      setState(() {
        isLoading = false;
      });

      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const HomePage()),
      );
    } catch (e) {
      setState(() {
        isLoading = false;
        pesanError = 'Daftar gagal: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(
        title: const Text('Daftar Akun'),
        backgroundColor: Colors.teal,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 10),
          TextField(
            onChanged: (value) {
              nama = value;
            },
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Nama',
              prefixIcon: Icon(Icons.person),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            onChanged: (value) {
              kelas = value;
            },
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Kelas',
              prefixIcon: Icon(Icons.school),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            onChanged: (value) {
              email = value;
            },
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              labelText: 'Email',
              prefixIcon: Icon(Icons.email),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            obscureText: !lihatPassword,
            onChanged: (value) {
              password = value;
            },
            decoration: InputDecoration(
              border: const OutlineInputBorder(),
              labelText: 'Password',
              prefixIcon: const Icon(Icons.lock),
              suffixIcon: IconButton(
                icon: Icon(
                  lihatPassword ? Icons.visibility : Icons.visibility_off,
                ),
                onPressed: () {
                  setState(() {
                    lihatPassword = !lihatPassword;
                  });
                },
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            pesanError ?? '',
            style: const TextStyle(color: Colors.red),
          ),
          const SizedBox(height: 12),
          isLoading ? const Center(child: CircularProgressIndicator()) : ElevatedButton(
            onPressed: register,
            child: const Text('Daftar'),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';

class InventarisPage extends StatelessWidget {
  const InventarisPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventaris'),
        backgroundColor: Colors.teal,
      ),
      body: const Center(
        child: Text('Inventaris', style: TextStyle(fontSize: 24)),
      ),
    );
  }
}
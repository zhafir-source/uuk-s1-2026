import 'package:flutter/material.dart';

class BerandaPage extends StatefulWidget {
  const BerandaPage({super.key});

  @override
  State<BerandaPage> createState() => _BerandaPageState();
}

class _BerandaPageState extends State<BerandaPage> {
  String kataCari = '';
  int bannerIndex = 0;

  List<String> banner = [
    'assets/images/banner1.jpg',
    'assets/images/banner2.jpg',
    'assets/images/banner3.jpg',
  ];

  List<String> semuaData = [
    'Mikroskop',
    'Gelas Ukur',
    'Multimeter',
    'Laptop Lab',
    'Tabung Reaksi',
    'Osiloskop',
  ];

  // nama kategori dan gambarnya (urutannya harus sama)
  List<String> namaKategori = ['Gelas', 'Elektronik', 'Optik', 'Pengukur'];
  List<String> gambarKategori = [
    'assets/images/gelas.png',
    'assets/images/elektronik.png',
    'assets/images/optik.png',
    'assets/images/pengukur.png',
  ];

  List<String> status = ['Available', 'Borrowed'];

  // kotak teks (Semua Data dan Status)
  Widget kotakTeks(String teks, Color warnaTeks, Color warnaLatar) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: warnaLatar,
        border: Border.all(color: Colors.teal.shade200),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(teks, style: TextStyle(color: warnaTeks)),
    );
  }

  // gambar dengan nama (Kategori)
  Widget kotakGambar(String gambar, String nama) {
    return Container(
      width: 100,
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.teal.shade200),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Container(
            height: 65,
            width: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(6),
              image: DecorationImage(
                image: AssetImage(gambar),
                fit: BoxFit.cover,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(nama, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }

  // judul bagian dengan garis teal di kiri
  Widget judul(String teks) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Row(
        children: [
          Container(width: 4, height: 18, color: Colors.teal),
          const SizedBox(width: 8),
          Text(
            teks,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  List<Widget> buatSemuaData() {
    List<Widget> hasil = [];
    for (int i = 0; i < semuaData.length; i++) {
      if (semuaData[i].toLowerCase().contains(kataCari.toLowerCase())) {
        hasil.add(kotakTeks(semuaData[i], Colors.black, Colors.white));
      }
    }
    if (hasil.isEmpty) {
      hasil.add(kotakTeks('Tidak ditemukan', Colors.grey, Colors.white));
    }
    return hasil;
  }

  List<Widget> buatKategori() {
    List<Widget> hasil = [];
    for (int i = 0; i < namaKategori.length; i++) {
      hasil.add(kotakGambar(gambarKategori[i], namaKategori[i]));
    }
    return hasil;
  }

  List<Widget> buatStatus() {
    List<Widget> hasil = [];
    for (int i = 0; i < status.length; i++) {
      bool tersedia = status[i] == 'Available';
      hasil.add(kotakTeks(
        status[i],
        tersedia ? Colors.green.shade800 : Colors.red.shade800,
        tersedia ? Colors.green.shade50 : Colors.red.shade50,
      ));
    }
    return hasil;
  }

  void gantiBanner(int arah) {
    setState(() {
      bannerIndex = bannerIndex + arah;
      if (bannerIndex < 0) {
        bannerIndex = banner.length - 1;
      }
      if (bannerIndex >= banner.length) {
        bannerIndex = 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(
        title: const Text('Beranda'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 1. search bar
          TextField(
            onChanged: (value) {
              setState(() {
                kataCari = value;
              });
            },
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white,
              hintText: 'Cari alat inventaris',
              prefixIcon: const Icon(Icons.search, color: Colors.teal),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.teal.shade200),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.teal.shade200),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // 2. carousel (geser kiri-kanan atau pakai tombol)
          GestureDetector(
            onHorizontalDragEnd: (details) {
              if (details.primaryVelocity! < 0) {
                gantiBanner(1);
              } else if (details.primaryVelocity! > 0) {
                gantiBanner(-1);
              }
            },
            child: Container(
              height: 170,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                image: DecorationImage(
                  image: AssetImage(banner[bannerIndex]),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: const Icon(Icons.chevron_left, color: Colors.teal),
                onPressed: () {
                  gantiBanner(-1);
                },
              ),
              Text('${bannerIndex + 1} / ${banner.length}'),
              IconButton(
                icon: const Icon(Icons.chevron_right, color: Colors.teal),
                onPressed: () {
                  gantiBanner(1);
                },
              ),
            ],
          ),

          // 3. tiga baris scroll horizontal
          judul('Semua Data'),
          SizedBox(
            height: 45,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: buatSemuaData(),
            ),
          ),

          judul('Kategori Peralatan'),
          SizedBox(
            height: 115,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: buatKategori(),
            ),
          ),

          judul('Status'),
          SizedBox(
            height: 45,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: buatStatus(),
            ),
          ),
        ],
      ),
    );
  }
}